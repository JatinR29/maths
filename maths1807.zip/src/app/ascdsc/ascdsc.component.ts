import { Component, OnInit, ViewChild, ViewChildren } from '@angular/core';

@Component({
  selector: 'app-ascdsc',
  templateUrl: './ascdsc.component.html',
  styleUrls: ['./ascdsc.component.css']
})
export class AscdscComponent implements OnInit {
  numberList = [];
  resultList= [];
  sortedList=[];
  dummyList=[];
  result;
  @ViewChild('num1') num1;
  @ViewChild('num2') num2;
  @ViewChild('num3') num3;
  @ViewChild('num4') num4;
  @ViewChild('num5') num5;
  @ViewChild('num6') num6;

  asc:boolean;
  dsc:boolean;

  constructor() { }

  ngOnInit() {
    this.generateNum();
  }

  chooseOption(value){
    console.log(value);
    if(value=='asc'){
      this.asc = true;
      this.dsc = false;
    }else{
      this.dsc = true;
      this.asc = false;
    }
  }

  generateNum(){
    for(let i=0;i<6;i++){
      this.numberList.push(Math.floor((Math.random() * 100) + 1));
    }

    this.dummyList = [...this.numberList];
    this.sortedList = this.dummyList.sort(function(a,b) { return a - b; });
  }

  ans(num1,num2,num3,num4,num5,num6){
      
      if(num1!=='' && num2!=='' && num3!=='' && num4!=='' && num5!=='' && num6!==''){
        this.resultList.push(num1,num2,num3,num4,num5,num6);
        this.result = "Right"
        
        //console.log(this.sortedList)
        console.log(this.dummyList);  
        console.log(this.resultList);
        if(this.asc){
          for(let i=0;i<6;i++){
            if(this.sortedList[i]!=this.resultList[i]){
              this.result = "Wrong";
              this.resultList = [];
            }
          }
        }else{
          for(let i=0;i<6;i++){
            if(this.sortedList[5-i]!=this.resultList[i]){
              this.result = "Wrong";
              this.resultList = [];
            }
          }
        }
        
      }else{
        this.result = "Wrong";
      }
      
  }

  newQue(){
    this.numberList=[];
    this.resultList=[];
    this.result='';
    console.log(this.num1.nativeElement.value);
    this.num1.nativeElement.value='';
    this.num2.nativeElement.value='';
    this.num3.nativeElement.value='';
    this.num4.nativeElement.value='';
    this.num5.nativeElement.value='';
    this.num6.nativeElement.value='';
    
    this.generateNum();
    
  }
}

import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-sum',
  templateUrl: './sum.component.html',
  styleUrls: ['./sum.component.css']
})
export class SumComponent implements OnInit {
  num1: number;
  num2: number;
  result: string;
  sum: number;
  userAns: number;
  dummyArray=[];
  dummuString='';
  @ViewChild('sumResult') sumResult;
  constructor() { }

  ngOnInit() {
    this.newQue();
  }
  newQue(){
    this.num1 = Math.floor((Math.random() * 1000) + 1);
    this.num2 = Math.floor((Math.random() * 1000) + 1);
    this.result='';
    this.sumResult.nativeElement.value='';
    this.dummyArray=[];
  }

  addResult(num){
    this.dummyArray.unshift(num);
    console.log(this.dummyArray);
    this.dummuString='';
    for(let i=0;i<this.dummyArray.length;i++){
      this.dummuString += this.dummyArray[i];
      
    }
    console.log(this.dummuString);
    this.userAns = Number(this.dummuString);
  }
  onClick(value){
    this.result='';
    this.sum = this.num1+this.num2;

    if(value==this.sum){
      this.result ='Right';
    }else {
      this.result = 'Wrong';
    }

      console.log(this.result);
    }

}

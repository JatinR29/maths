import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router'

import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { ComparisonComponent } from './comparison/comparison.component';
import { ContentComponent } from './content/content.component';
import { RouteService } from './route.service';
import { AscdscComponent } from './ascdsc/ascdsc.component';
import { SumComponent } from './sum/sum.component';
import { FormsModule } from '../../node_modules/@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    ComparisonComponent,
    ContentComponent,
    AscdscComponent,
    SumComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule,
    RouteService,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
